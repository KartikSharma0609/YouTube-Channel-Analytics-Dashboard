import requests
import pandas as pd

API_KEY = 'YOUR_API_KEY'  # Replace with your real API key
CHANNEL_ID = 'YOUR_CHANNEL_ID'  # Replace with your channel ID

def get_channel_stats(channel_id):
    url = f"https://www.googleapis.com/youtube/v3/channels?part=statistics&id={channel_id}&key={API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        stats = response.json()['items'][0]['statistics']
        return stats
    else:
        print("Failed to fetch data:", response.text)
        return {}

channel_stats = get_channel_stats(CHANNEL_ID)

if channel_stats:
    df = pd.DataFrame([channel_stats])
    df.to_csv('youtube_channel_stats.csv', index=False)
    print("Data saved to youtube_channel_stats.csv")
else:
    print("No data to save.")
