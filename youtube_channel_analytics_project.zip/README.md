# YouTube Channel Analytics Dashboard

This project extracts YouTube channel statistics using Python and visualizes them using Power BI.

## 🔧 Requirements

- Python 3.x
- pandas
- requests
- YouTube Data API Key

## 📁 Files

- `youtube_stats.py` - Python script to fetch data
- `youtube_channel_stats.csv` - Sample dataset
- `README.md` - Project documentation

## 🚀 How to Run

1. Replace `YOUR_API_KEY` and `YOUR_CHANNEL_ID` in the script.
2. Run the script using:
   ```
   python youtube_stats.py
   ```
3. Open Power BI and import the CSV to create your dashboard.

## 📊 Power BI Ideas

- Total subscribers, views, video count
- Top videos by views
- Subscriber growth over time (if extended)

Enjoy!
